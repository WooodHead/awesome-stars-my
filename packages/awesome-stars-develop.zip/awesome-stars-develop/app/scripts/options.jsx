import React from 'react';
import ReactDOM from 'react-dom';

import OptionPage from './components/options/OptionPage';

ReactDOM.render(<OptionPage />, document.getElementById('container'));
