export const BASE = 16;
export const rem = num => `${(num / 16).toFixed(4)}rem`;
