import { Client } from 'chomex';

const client = new Client(chrome.runtime);

export default client;
